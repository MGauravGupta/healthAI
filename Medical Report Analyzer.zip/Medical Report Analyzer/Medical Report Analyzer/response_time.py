import os
import time
import PyPDF2
from fpdf import FPDF

# Extract text from PDF
def extract_text_from_pdf(pdf_file):
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    text = ""
    for page in pdf_reader.pages:
        text += page.extract_text()
    return text

# Mock analysis function (replace with actual AI-based analysis)
def analyze_content(text, prompt):
    # Mock response (replace with API or real logic)
    time.sleep(0.1)  # Simulate processing delay
    return f"Mock result for prompt: {prompt}"

# Generate Findings PDF
def generate_findings_pdf(findings, output_path):
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    
    # Add title
    pdf.set_font("Arial", style="B", size=14)
    pdf.cell(200, 10, "Medical Report Analysis Findings", ln=True, align="C")
    pdf.ln(10)
    
    # Add findings content
    pdf.set_font("Arial", size=10)
    for line in findings.split("\n"):
        pdf.multi_cell(0, 10, line)
    
    # Save PDF
    pdf.output(output_path)

def process_pdf():
    pdf_file = "C:\\Users\\Gaurav Gupta\\Downloads\\2a7a59c6-8a30-4a95-9e54-cdf802e565be.pdf"
    findings = ""

    try:
        findings += f"Processing {pdf_file}...\n"

        # Measure text extraction time
        start_time = time.time()
        with open(pdf_file, "rb") as f:
            extracted_text = extract_text_from_pdf(f)
        extraction_time = time.time() - start_time
        findings += f"Text extraction took {extraction_time:.2f} seconds.\n"

        # Prompts for analysis
        prompts = [
            "Abnormalities Found",
            "Conditions of concern",
            "Suggested Medications",
            "Suggested Food Supplements",
            "Suggested Activities"
        ]

        for prompt in prompts:
            start_time = time.time()
            response = analyze_content(extracted_text, prompt)
            analysis_time = time.time() - start_time
            findings += f"Analysis for '{prompt}' took {analysis_time:.2f} seconds.\n"
            findings += f"{prompt}: {response}\n\n"

    except Exception as e:
        findings += f"Error processing {pdf_file}: {e}\n"

    # Generate PDF report
    pdf_output_path = "5be.pdf"
    generate_findings_pdf(findings, pdf_output_path)
    print(f"Findings saved to {pdf_output_path}")

if __name__ == "__main__":
    process_pdf()
