import os
import streamlit as st
import PyPDF2
import google.generativeai as genai
from dotenv import load_dotenv
from docx import Document

# Load API Key from .env file
load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", None)

# Allow manual entry of API key if not found
if not GOOGLE_API_KEY:
    GOOGLE_API_KEY = st.text_input("Enter your Google API Key:", type="password")

# Configure Generative AI if API Key is available
if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)
else:
    st.error("No API key provided. Please enter the key to proceed.")

# Load content from the updated RAG data file
def load_rag_data(docx_file):
    try:
        document = Document(docx_file)
        rag_content = ""
        for paragraph in document.paragraphs:
            rag_content += paragraph.text + "\n"
        return rag_content
    except Exception as e:
        return f"Error loading RAG data: {e}"

# Extract text from PDF
def extract_text_from_pdf(pdf_file):
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    text = ""
    for page in pdf_reader.pages:
        text += page.extract_text()
    return text

# Analyze content using Generative AI
def analyze_content(text, prompt):
    try:
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(text + prompt)
        if response and response.candidates:
            content = response.candidates[0].content.parts[0].text
            return content
        else:
            return "This information is needed to be able to answer better, which I currently do not have. If you can provide the information, I can assist further."
    except Exception as e:
        return f"Error during analysis: {e}"

# Medical Report Analyzer Page
def report_analyzer_page():
    st.title("📄 Medical Report Analyzer")
    st.write("Upload a medical report in PDF format to analyze its content and generate tailored recommendations. 🩺")

    if not GOOGLE_API_KEY:
        st.error("API key is not configured. Please enter your API key to proceed.")
        return

    # File uploader
    uploaded_file = st.file_uploader("📂 Upload PDF", type="pdf")

    if uploaded_file:
        # Extract text
        with st.spinner("🕒 Extracting text from the PDF..."):
            pdf_text = extract_text_from_pdf(uploaded_file)
            st.text_area("📜 Extracted Report Content:", pdf_text, height=300)

        # Analyze the report
        with st.spinner("🔍 Analyzing medical report..."):
            abnormalities_prompt = "List all abnormalities found in the medical report."
            conditions_prompt = "Identify any conditions in the report that should be of concern."
            medications_prompt = """
            Suggest medications based on the report with an explanation of why they are recommended.
            """
            supplements_prompt = """
            Recommend food supplements and explain why they are beneficial for the patient's condition.
            """
            activities_prompt = """
            Suggest activities suitable for the patient's conditions with an explanation of their benefits.
            """

            abnormalities = analyze_content(pdf_text, abnormalities_prompt)
            conditions = analyze_content(pdf_text, conditions_prompt)
            medications = analyze_content(pdf_text, medications_prompt)
            supplements = analyze_content(pdf_text, supplements_prompt)
            activities = analyze_content(pdf_text, activities_prompt)

        # Display results
        st.success("✅ Analysis Complete!")
        st.subheader("🔍 Abnormalities Found")
        st.markdown(abnormalities)

        st.subheader("⚠️ Conditions to Be Concerned About")
        st.markdown(conditions)

        st.subheader("💊 Suggested Medications")
        st.markdown(medications)

        st.subheader("🍎 Suggested Food Supplements")
        st.markdown(supplements)

        st.subheader("🏃 Suggested Activities")
        st.markdown(activities)

        # Store extracted content and results in session state
        st.session_state["extracted_text"] = pdf_text
        st.session_state["analysis_results"] = {
            "abnormalities": abnormalities,
            "conditions": conditions,
            "medications": medications,
            "supplements": supplements,
            "activities": activities,
        }

# Chatbot Page
def chatbot_page():
    st.title("🤖 Medical Chatbot")
    st.write("Discuss recommendations or ask health-related questions. 💬")

    # Chat history
    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = []

    # Display previous chat history
    for chat in st.session_state["chat_history"]:
        if chat["type"] == "user":
            st.write(f"**You:** {chat['content']}")
        else:
            st.write(f"**Chatbot:** {chat['content']}")

    # User input
    user_input = st.text_input("💬 Enter your question or feedback:")

    if user_input:
        # Add user input to chat history
        st.session_state["chat_history"].append({"type": "user", "content": user_input})

        # Check if analysis results exist
        if "analysis_results" in st.session_state:
            recommendations = st.session_state["analysis_results"]
            recommendations_text = (
                f"Abnormalities: {recommendations['abnormalities']}\n"
                f"Conditions: {recommendations['conditions']}\n"
                f"Medications: {recommendations['medications']}\n"
                f"Supplements: {recommendations['supplements']}\n"
                f"Activities: {recommendations['activities']}\n"
            )
            chatbot_prompt = f"""
            The user has asked about their medical report or provided feedback:
            {user_input}

            Based on the following recommendations:
            {recommendations_text}

            Respond to the user appropriately. If they have specific questions, provide answers or adjust the recommendations as needed.
            """
            with st.spinner("🤔 Processing your input..."):
                response = analyze_content(recommendations_text, chatbot_prompt)
        else:
            # If no analysis results exist, fallback to general response
            fallback_prompt = f"""
            User Query: {user_input}
            No medical report analysis is available. Use general medical knowledge to answer the user's question.
            """
            with st.spinner("🤖 Generating a response..."):
                response = analyze_content("", fallback_prompt)

        # Add the chatbot's response to the chat history
        st.session_state["chat_history"].append({"type": "bot", "content": response})
        st.write(f"**Chatbot:** {response}")

# Login Page
def login_page():
    st.title("🔒 Login Page")
    st.write("Welcome to the Medical Report Analyzer & Chatbot! Please log in to continue.")
    
    # User input for login
    username = st.text_input("👤 Username:")
    password = st.text_input("🔑 Password:", type="password")
    
    if st.button("Login"):
        if username == "admin" and password == "password":  # Replace with a secure authentication method
            st.session_state["authenticated"] = True
            st.success("Login successful! 🎉")
        else:
            st.error("Invalid username or password. ❌")

# Main App
def main():
    if "authenticated" not in st.session_state:
        st.session_state["authenticated"] = False

    if not st.session_state["authenticated"]:
        login_page()
    else:
        st.sidebar.title("🗂️ Navigation")
        choice = st.sidebar.radio(
            "Go to:",
            [
                "📄 Medical Report Analyzer",
                "🤖 Medical Chatbot",
                "🔒 Logout",
            ],
        )

        if choice == "📄 Medical Report Analyzer":
            report_analyzer_page()
        elif choice == "🤖 Medical Chatbot":
            chatbot_page()
        elif choice == "🔒 Logout":
            st.session_state["authenticated"] = False
            st.warning("You have been logged out. 🚪")

if __name__ == "__main__":
    main()
